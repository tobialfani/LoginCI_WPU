<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <!-- <div class="card" style="width: 18rem;">
    <img class="card-img-top" src="<?= base_url('assets/img/profile/'.$user['image']); ?>" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title"><?= $user['name']; ?></h5>
      <a href="#" class="btn btn-primary">Change</a>
    </div>
  </div> -->

  <?= form_open_multipart('user/edit'); ?>
    <div class="row">
      <div class="col-3">
        <img src="<?= base_url('assets/img/profile/'.$user['image']); ?>" alt="..." class="img-thumbnail">
        <input type="file" class="custom-file-input" id="customFile">
        <label for="customFile" class="custom-file-label btn btn-outline-primary mx-auto w-100">Choose File</label>
      </div>

      <div class="col-9">
        <table class="table table-striped">
          <thead class="thead-dark">
            <tr>
              <th colspan="3" class="text-center">
                Edit Biodata
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Name</td>
              <td>
                <div class="form-group">
                  <input type="text" class="form-control" name="name" value="<?= $user['name']; ?>">
                </div>
              </td>
            </tr>
            <tr>
              <td>Email</td>
              <td>
                <div class="form-group">
                  <input type="text" class="form-control" name="email" value="<?= $user['email']; ?>">
                </div>
              </td>
            </tr>
            <tr>
              <td>Member Since</td>
              <td>
                <div class="form-group">
                  <input type="text" class="form-control" id="formGroupExampleInput" value="<?= date('d F Y',$user['date_created']); ?>">
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </form>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

