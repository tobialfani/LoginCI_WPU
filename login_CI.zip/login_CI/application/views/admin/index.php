

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <!-- <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="<?= base_url('assets/img/profile/'.$user['image']); ?>" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title"><?= $user['name']; ?></h5>
              <a href="#" class="btn btn-primary">Change</a>
            </div>
          </div> -->
          <div class="row">
            <div class="col-3">
              <img src="<?= base_url('assets/img/profile/'.$user['image']); ?>" alt="..." class="img-thumbnail">
              <button type="button" class="btn btn-outline-primary mx-auto w-100">Change Image</button>
            </div>

            <div class="col-9">
              <table class="table table-striped">
                <thead class="thead-dark">
                  <tr>
                    <th colspan="3" class="text-center">
                      My Biodata (Admin)
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Name</td>
                    <td> : </td>
                    <td><?= $user['name']; ?></td>
                  </tr>
                  <tr>
                    <td>Email</td>
                    <td> : </td>
                    <td><?= $user['email']; ?></td>
                  </tr>
                  <tr>
                    <td>Born</td>
                    <td> : </td>
                    <td>Tulungagung, 12-10-1999</td>
                  </tr>
                  <tr>
                    <td>Address</td>
                    <td> : </td>
                    <td>Banjarejo Village</td>
                  </tr>
                  <tr>
                    <td>Gender</td>
                    <td> : </td>
                    <td>Male</td>
                  </tr>
                  <tr>
                    <td>Member Since</td>
                    <td> : </td>
                    <td><?= date('d F Y',$user['date_created']); ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

