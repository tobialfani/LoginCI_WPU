

  <!-- Begin Page Content -->
  <div class="container-fluid">
      
    <?= $this->session->flashdata('message'); ?>
    
    <table class="table table-striped">
      <thead>
        <tr class="table-primary text-secondary">
          <th colspan="3" class="text-center">
            Access For <?= $role['role']; ?>
          </th>
        </tr>
        <tr class="table-success">
          <th>
            No
          </th>
          <th>
            Menu
          </th>
          <th class="text-center">
            Access
          </th>
        </tr>
      </thead>
      <tbody>
        <?php $nomor = 1 ?>
        <?php foreach ($menu as $m ) :  ?>
        <tr>
          <td><?= $nomor++; ?></td>
          <td><?= $m['menu'] ?></td>
          <td class="text-center">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" <?= check_access($role['id'],$m['id']); ?> data-role="<?= $role['id']; ?>" data-menu="<?= $m['id']; ?>" >
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

  </div>
  <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Button trigger modal -->